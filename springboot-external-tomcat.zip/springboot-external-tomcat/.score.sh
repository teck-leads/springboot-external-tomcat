#!/bin/sh
count=1
mvn tomcat7:run > server.txt 2>&1 &
pid=$!
while [ "$(cat server.txt | grep http-bio-8000)" == "" ] && [ $count -lt 40 ]
do
sleep 1
count=$((count + 1))
done
#JAVA_HOME=/usr/lib/jvm/java-1.8.0-openjdk-amd64/jre/
python3 -m pytest tests.py --junitxml=unit.xml
kill -9 $pid
FS_SCORE=`python3 parser.py`
echo "FS_SCORE:$FS_SCORE%"
