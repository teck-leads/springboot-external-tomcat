package com.spring.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.project.entity.User;
import com.spring.project.sevice.UserService;

@RestController
public class UserController {
	@Autowired
	private UserService userService;
	
	@PostMapping("/user")
	public ResponseEntity<User> saveUser(@RequestBody User user) {
		User saveUser = userService.saveUser(user);
		return new ResponseEntity<>(saveUser,HttpStatus.OK);
	}
	
	@GetMapping("/user")
	public ResponseEntity<List<User>> findAllUsers() {
		List<User> findAllUsers = userService.findAllUsers();
		return new ResponseEntity<>(findAllUsers,HttpStatus.OK);
	}
	
	@GetMapping("/user/{id}")
	public ResponseEntity<User> findById(@PathVariable("id") Integer id) {
		User findById = userService.findById(id);
		return new ResponseEntity<>(findById,HttpStatus.OK);
	}
	
	@DeleteMapping("/user/{id}")
	public ResponseEntity<Void> deleteById(@PathVariable("id") Integer id) {
		userService.deleteUserById(id);
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
}
