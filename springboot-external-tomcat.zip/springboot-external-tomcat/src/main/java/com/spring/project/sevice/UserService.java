package com.spring.project.sevice;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.project.Dao.UserRepository;
import com.spring.project.entity.User;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;

	public List<User> findAllUsers() {
		List<User> findAll = userRepository.findAll();
		return findAll;
	}

	public User findById(Integer id) {
		Optional<User> findById = userRepository.findById(id);

		if (findById.isPresent()) {
			return findById.get();
		} else {
			return new User();
		}
	}
	
	
	public User saveUser(User user) {
		User savedUser = userRepository.save(user);
		return savedUser;
	}
	
	public void deleteUserById(Integer id) {
		Optional<User> findById = userRepository.findById(id);

		if (findById.isPresent()) {
			userRepository.deleteById(id);
		} 
	}
}
