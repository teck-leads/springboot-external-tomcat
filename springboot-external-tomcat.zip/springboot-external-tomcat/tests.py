import pytest
import json
import base64
import os
import requests

class Test_API:

    def testRegister(self):
        url = "http://localhost:8000/SpringRest/user"
        payload = "{\n\t\"id\": 1,\n\t\"name\": \"jhon\",\n\t\"email\": \"jhon@gmail.com\"\n}"
        headers = {'Content-Type': "application/json",
                   'cache-control': "no-cache"}
        response = requests.post(url, data=payload, headers=headers)
        assert response.status_code == 200
        url = "http://localhost:8000/SpringRest/user"
        payload = "{\n\t\"id\": 2,\n\t\"name\": \"jhon1\",\n\t\"email\": \"jhon1@gmail.com\"\n}"
        headers = {'Content-Type': "application/json",
                   'cache-control': "no-cache"}
        response = requests.post(url, data=payload, headers=headers)
        assert response.status_code == 200
        url = "http://localhost:8000/SpringRest/user/1"
        headers = {'Content-Type': "application/json"}
        response = requests.get(url, data=payload, headers=headers)
        assert response.json() == {
            "id": 1,
            "name": "jhon",
            "email": "jhon@gmail.com"
        }
        url = "http://localhost:8000/SpringRest/user/2"
        headers = {'Content-Type': "application/json"}
        response = requests.get(url, headers=headers)
        assert response.json() == {
            "id": 2,
            "name": "jhon1",
            "email": "jhon1@gmail.com"
        }
    def testGetAllUsers(self):
        url = "http://localhost:8000/SpringRest/user/"
        headers = {'Content-Type': "application/json"}
        response = requests.get(url,headers=headers)
        assert response.json() == [
            {
        "id": 1,
            "name": "jhon",
            "email": "jhon@gmail.com"
    },
    {
       "id": 2,
            "name": "jhon1",
            "email": "jhon1@gmail.com"
    }
        ]
    def testDeleteUser(self):
        url = "http://localhost:8000/SpringRest/user/1"
        headers = {'Content-Type': "application/json"}
        response = requests.delete(url,headers=headers)
        assert response.status_code == 200
        url = "http://localhost:8000/SpringRest/user/"
        headers = {'Content-Type': "application/json"}
        response = requests.get(url, headers=headers)
        assert response.json() == [
            {
            "id": 2,
            "name": "jhon1",
            "email": "jhon1@gmail.com"
            }
        ]